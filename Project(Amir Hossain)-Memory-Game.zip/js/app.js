/*
 * Create a list that holds all of your cards
 */


/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

let cardsOpened = [];
let moves, match, win, firstCard;
let netTime, seconds, minutes, startTimer;
const $min = $(".minutes");
const $sec = $(".seconds");
const $deck = $(".deck");
const $count = $(".moves");
const $myModal = $("#myModal");
const $hide = $(".close");
const $starsCount = $(".stars");
let cardList = ["fa fa-diamond", "fa fa-paper-plane-o", "fa fa-anchor",
   "fa fa-bolt", "fa fa-cube", "fa fa-anchor", "fa fa-leaf",
   "fa fa-bicycle", "fa fa-diamond", "fa fa-bomb", "fa fa-leaf",
   "fa fa-bomb", "fa fa-bolt", "fa fa-bicycle", "fa fa-paper-plane-o", "fa fa-cube"
];

/*
  Runs when game is reset
*/

function init() {
   cardList = shuffle(cardList);
   cardsOpened = [];
   moves = 0;
   match = 0;
   win = false;
   firstCard=true;
   $sec.html("00");
   $min.html("00");
   $myModal.css("display", "none");
   $count.html(moves);
   $deck.empty();
   for (let i = 0; i < cardList.length; i++) {
      $deck.append('<li id="' + i + '" class="card"><i class="' + cardList[i] + '"></i></li>');
   }
   for (let i = 0; i < cardList.length; i++) {
      let listSelect = $("li#" + i);
      let event = cardList[i];
      addListener(listSelect, event);
   }
   updateStars();
}
$(document).ready(function() {
   init();
});

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}

/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */

/*
  Set up the event listener for a card
*/

function addListener(listSelect, event) {
   listSelect.click(function() {
     value=listSelect.hasClass("match")||listSelect.hasClass("show open");
     if(!value){
      displaySymbol(listSelect);
      insertCard(listSelect, event);
    }
   });
}

/*
  Display the card's symbol
*/

function displaySymbol(listSelect) {
   listSelect.addClass("show open");
   if(firstCard==true){
   timer();
 }
 firstCard=false;
}
$(".restart").click(function() {
   clearInterval(startTimer);
   init();
});

/*
  Add the card to a *list* of "open" cards
*/

function insertCard(listSelect, event) {
   cardsOpened.push([event, listSelect]);
   setTimeout(function() {
      if (cardsOpened.length > 1) {
         var x = cardsOpened.length;
         if (cardsOpened[x - 2][0] === cardsOpened[x - 1][0]) {
            matchCorrect(x);
         } else {
            matchIncorrect(x);
         }
         movesCount();
         displayWinner();
      }
   }, 200);
}

/*
  If the list already has another card, check to see if the two cards match
  If the cards do match, lock the cards in the open position
*/

function matchCorrect(x) {
  cardsOpened[x - 2][1].removeClass("show open");
  cardsOpened[x - 1][1].removeClass("show open");
  cardsOpened[x - 2][1].addClass("match");
  cardsOpened[x - 1][1].addClass("match");
  cardsOpened = [];
  match += 2;
}

/*
  If the cards do not match, remove the cards from the list and hide the card's symbol
*/

function matchIncorrect(x) {
   cardsOpened[x - 2][1].removeClass("show open");
   cardsOpened[x - 1][1].removeClass("show open");
   cardsOpened = [];
}

/*
  Increment the move counter and display it on the page
*/

function movesCount() {
   moves += 1;
   $count.html(moves);
   updateStars();
}

function updateStars() {
   if (moves > 17) {
      $starsCount.empty();
      $starsCount.append("<li><i class='fa fa-star'></i></li>");
   } else if (moves > 10) {
      $starsCount.empty();
      $starsCount.append("<li><i class='fa fa-star'></i></li>");
      $starsCount.append("<li><i class='fa fa-star'></i></li>");
   } else {
      $starsCount.empty();
      $starsCount.append("<li><i class='fa fa-star'></i></li>" +
         "<li><i class='fa fa-star'></i></li>" +
         "<li><i class='fa fa-star'></i></li>");
   }
}

function timer() {
   netTime = 0;
   startTimer = setInterval(function() {
      ++netTime;
      seconds = netTime % 60;
      minutes = parseInt(netTime / 60);
      $sec.html(pad(netTime % 60));
      $min.html(pad(parseInt(netTime / 60)));
      if (win) {
         clearInterval(startTimer);
         displayModal();
      }
   }, 1000);

   function pad(val) {
      return val > 9 ? val : "0" + val;
   }
}

/*
  If all cards have matched, display a message with the final score
*/

function displayWinner() {
   if (match === 16) {
      console.log("Won");
      win = true;
   }
}

function displayModal() {
   $myModal.css("display", "block");
   $hide.click(function() {
      $myModal.css("display", "none");
   });
   $(window).click(function(e) {
      if (e.target.id == "myModal") {
         $myModal.css("display", "none");
      }
   });
}


